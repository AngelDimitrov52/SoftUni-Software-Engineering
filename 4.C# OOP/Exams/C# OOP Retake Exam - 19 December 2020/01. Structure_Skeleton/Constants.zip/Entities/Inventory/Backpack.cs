﻿using System;
using System.Collections.Generic;
using System.Text;
using WarCroft.Entities.Inventory.Contracts;

namespace WarCroft.Entities.Inventory
{
    public class Backpack : Bag
    {
        public Backpack() : base(100)
        {
        }
    }
}
